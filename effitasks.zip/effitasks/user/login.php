<?php

$dsn = "mysql:host=localhost;dbname=effitasks";
$pdo = new PDO($dsn, 'root', 'root');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Récupérer l'utilisateur avec le nom d'utilisateur donné
    $sql = "SELECT * FROM users WHERE username = :username";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([':username' => $username]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    // Vérifier si l'utilisateur existe et si le mot de passe est correct
    if ($user && password_verify($password, $user['password'])) {
        session_start();
        $_SESSION['user_id'] = $user['id'];
        // var_dump($_SESSION);
        // die();
        header("Location: /dashboard.php");
        exit();
    } else {
        echo "Invalid email or password";
    }
}
