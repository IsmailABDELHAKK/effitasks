<?php

$dsn = "mysql:host=localhost;dbname=effitasks";
$pdo = new PDO($dsn, 'root', 'root');


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Requête pour s'inscrire
    $firstName = $_POST['first_name'];
    $lastName = $_POST['last_name'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $avatar = $_POST['avatar'];

    // Hacher le mot de passe avant de le stocker
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    $sql = "INSERT INTO users (first_name, last_name, username, password, avatar) 
            VALUES (:first_name, :last_name, :username, :password, :avatar)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        ':first_name' => $firstName,
        ':last_name' => $lastName,
        ':username' => $username,
        ':password' => $hashedPassword,
        ':avatar' => $avatar
    ]);
    header("Location: /index.php");
    exit();
}
// var_dump ($_POST);