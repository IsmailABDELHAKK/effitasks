const aside = document.querySelector("aside");

aside.addEventListener("click", function () {
  document.querySelector("#sidebar").classList.toggle("expand");
});

