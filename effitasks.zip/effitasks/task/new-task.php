<?php

$dsn = "mysql:host=localhost;dbname=effitasks";
$pdo = new PDO($dsn, 'root', 'root');


// Requête pour insérer la nouvelle tâche
$sql = "INSERT INTO tasks (name, description, status_id, categorie_id, created_at, deadline, user_id, importance_id) 
    VALUES (:name, :description, :status_id, :category_id, :created_at, :deadline, :user_id, :importance_id)";  

$stm = $pdo->prepare($sql);
$stm->execute([
    ':name' => $_POST['name'],
    ':description' => $_POST['description'],
    ':status_id' => $_POST['status'],
    ':category_id' => $_POST['category'],
    ':created_at' => $_POST['created_at'],
    ':deadline' => $_POST['deadline'],
    ':user_id' => 22,
    ':importance_id' => $_POST['importance']
])    ;

header("Location: index.php");
exit();