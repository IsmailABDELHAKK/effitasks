<?php

$dsn = "mysql:host=localhost;dbname=effitasks";
$pdo = new PDO($dsn, 'root', 'root');


// Requête pour récupérer les informations de la tâche à modifier
$sql = "SELECT * FROM tasks WHERE id = :id";
$stm = $pdo->prepare($sql);
$stm->execute([':id' => $_GET['id']]);
$task = $stm->fetch(PDO::FETCH_ASSOC);

// Vérifie si la requête est une mise à jour
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Requête pour mettre à jour la tâche
    $sql = "UPDATE tasks SET name = :name, description = :description, status_id = :status_id, 
            categorie_id = :category_id, deadline = :deadline, importance_id = :importance_id 
            WHERE id = :id";

    $stm = $pdo->prepare($sql);
    $stm->execute([
        ':name' => $_POST['name'],
        ':description' => $_POST['description'],
        ':status_id' => $_POST['status'],
        ':category_id' => $_POST['category'],
        ':deadline' => $_POST['deadline'],
        ':importance_id' => $_POST['importance'],
        ':id' => $_POST['id']
    ]);

    header("Location: index.php");
    exit();
}
var_dump($task);
require_once 'functions.php';
$currentDate = date('Y-m-d');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modifier la tâche</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <!-- Modal -->
        <div class="modal fade show" id="taskModal" tabindex="-1" aria-labelledby="taskModalLabel" aria-modal="true" role="dialog" style="display: block;">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="taskModalLabel">Modifier la tâche</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" onclick="window.location.href='index.php';"></button>
                    </div>
                    <div class="modal-body">
                        <form method="POST" action="update-task.php?id=<?= $task['id'] ?>">
                            <input type="hidden" name="id" value="<?= $task['id'] ?>">
                            <div class="form-group">
                                <label for="name">Nom de la tâche</label>
                                <input type="text" class="form-control" id="name" name="name" value="<?= $task['name'] ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="description">Description de la tâche</label>
                                <textarea class="form-control" id="description" name="description" rows="3" required><?= $task['description'] ?></textarea>
                            </div>
                            <div class="form-group">
                                <label for="status">Statut</label>
                                <select class="form-control" id="status" name="status" required>
                                    <?php foreach ($status as $statusItem) : ?>  
                                        <option value="<?= $statusItem['id'] ?>" <?= $statusItem['id'] == $task['status_id'] ? 'selected' : '' ?>>
                                            <?= $statusItem['name'] ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="category">Catégorie</label>
                                <select class="form-control" id="category" name="category" required>
                                    <?php foreach ($categories as $category) : ?>  
                                        <option value="<?= $category['id'] ?>" <?= $category['id'] == $task['categorie_id'] ? 'selected' : '' ?>>
                                            <?= $category['name'] ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="importance">Importance</label>
                                <select class="form-control" id="importance" name="importance" required>
                                    <?php foreach ($importances as $importance) : ?>  
                                        <option value="<?= $importance['id'] ?>" <?= $importance['id'] == $task['importance_id'] ? 'selected' : '' ?>>
                                            <?= $importance['name'] ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="created_at">Date de création</label>
                                <input type="date" class="form-control" id="created_at" name="created_at" value="<?= $task['created_at'] ?>" readonly required>
                            </div>
                            <div class="form-group">
                                <label for="deadline">Date d'échéance</label>
                                <input type="date" class="form-control" id="deadline" name="deadline" value="<?= $task['deadline'] ?>" required>
                            </div>
                            <button type="submit" class="btn btn-success">Modifier la tâche</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>
</html>
