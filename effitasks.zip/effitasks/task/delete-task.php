<?php

$dsn = "mysql:host=localhost;dbname=effitasks";
$pdo = new PDO($dsn, 'root', 'root');

$taskId = $_GET['id'];

// Requête pour supprimer la tâche
$sql = "DELETE FROM tasks WHERE id = :id";
$stmt = $pdo->prepare($sql);
$stmt->execute([':id' => $taskId]);

header("Location: /index.php");
exit();
