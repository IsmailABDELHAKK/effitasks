<?php
require_once 'functions.php';

$currentDate = date('Y-m-d');
?>
<div class="modal fade" id="taskModal" tabindex="-1" aria-labelledby="taskModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="taskModalLabel">Créer une tâche</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <form method="POST" action="task/new-task.php">
                                <div class="form-group">
                                    <label for="name">Nom de la tâche</label>
                                    <input type="text" class="form-control" id="name" name="name" required>
                                </div>
                                <div class="form-group">
                                    <label for="description">Description de la tâche</label>
                                    <textarea class="form-control" id="description" name="description" rows="3" required></textarea>
                                </div>
                                <div class="form-group">
                                    <label for="status">Statut</label>
                                    <select class="form-control" id="status" name="status" required>
                                        <?php foreach ($status as $status) :?>  
                                            <option value="<?=$status['id'] ?>">
                                                <?= $status['name'] ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="category">Catégorie</label>
                                    <select class="form-control" id="category" name="category" required>
                                        <?php 
                                        foreach ($categories as $category) :?>  
                                            <option value="<?=$category['id'] ?>">
                                                <?= $category['name'] ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>

                                <div class="form-group">
                                    <label for="importance">Importance</label>
                                    <select class="form-control" id="importance" name="importance" required>
                                        <?php 
                                        foreach ($importances as $importance) :?>  
                                            <option value="<?=$importance['id'] ?>">
                                                <?= $importance['name'] ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="created_at">Date de création</label>
                                    <input type="date" class="form-control" id="created_at" name="created_at" value="<?= $currentDate ?>" readonly required>
                                </div>
                                <div class="form-group">
                                    <label for="deadline">Date d'échéance</label>
                                    <input type="date" class="form-control" id="deadline" name="deadline" required>
                                </div>
                                <button type="submit" class="btn btn-success">Créer la tâche</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>