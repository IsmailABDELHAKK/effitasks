<?php

$dsn = "mysql:host=localhost;dbname=effitasks";
$pdo = new PDO($dsn, 'root', 'root');



// Vérifier si le formulaire de modification de tâche a été soumis
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['editTask'])) {
    $taskId = $_POST['taskId'];
    $taskName = $_POST['taskName'];
    $taskDescription = $_POST['taskDescription'];
    $taskStatus = $_POST['taskStatus'];
    $taskCategory = $_POST['taskCategory'];
    $creationDate = $_POST['creationDate'];
    $deadlineDate = $_POST['deadlineDate'];

    
// Requête pour modifier la tâche
    $sql = "UPDATE tasks SET name = :name, description = :description, status_id = (SELECT id FROM status WHERE name = :status), 
            categorie_id = (SELECT id FROM categories WHERE name = :category), created_at = :created_at, deadline = :deadline 
            WHERE id = :id";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        ':name' => $taskName,
        ':description' => $taskDescription,
        ':status' => $taskStatus,
        ':category' => $taskCategory,
        ':created_at' => $creationDate,
        ':deadline' => $deadlineDate,
        ':id' => $taskId
    ]);

    header("Location: dashboard.php");
    exit();
}

// Vérifier si une tâche doit être supprimée
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['deleteTask'])) {
    $taskId = $_POST['taskId'];

    // Requête pour supprimer la tâche
    $sql = "DELETE FROM tasks WHERE id = :id";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([':id' => $taskId]);

    header("Location: dashboard.php");
    exit();
}

// Requête pour récupérer les tâches
$sql = "SELECT tasks.*, 
        users.first_name AS user_first_name, users.last_name AS user_last_name,
        status.name AS status_name, categories.name AS category_name 
        FROM tasks
        LEFT JOIN status ON tasks.status_id = status.id
        LEFT JOIN categories ON tasks.categorie_id = categories.id
        LEFT JOIN users ON tasks.user_id = users.id";
$stmt = $pdo->prepare($sql);
$stmt->execute();
$tasks = $stmt->fetchAll(PDO::FETCH_ASSOC);

// selec all categories

$sql = "SELECT * FROM categories";
$stmt = $pdo->prepare($sql);
$stmt->execute();
$categories = $stmt->fetchAll(PDO::FETCH_ASSOC);

$sql = "SELECT * FROM status";
$stmt = $pdo->prepare($sql);
$stmt->execute();
$status = $stmt->fetchAll(PDO::FETCH_ASSOC);

$sql = "SELECT * FROM importances";
$stmt = $pdo->prepare($sql);
$stmt->execute();
$importances = $stmt->fetchAll(PDO::FETCH_ASSOC);


function renderTasks($status, $statusLabel, $badgeClass) {
    $tasks = getTaskByStatus($status);
    ?>
    <div class="col-12 col-md-4">
    <div class="card border-1 mb-3 small-card">
        <div class="card-body py-4 text-center">
            <h5 class="mb-2 fw-bold"><?= $statusLabel ?></h5>
        </div>
    </div>
    <div class="justify-content-center">
        <?php foreach ($tasks as $task) : ?>
            <div class="card mb-3 position-relative">
                <div class="card-body">
                <span class="badge <?= $badgeClass ?> position-absolute top-0 end-0 m-2 p-2"><?= strtoupper($task['importance_name']) ?></span>
                <span class="badge <?= $badgeClass ?> position-absolute top-0 start-0 m-2 p-2"><?= strtoupper($task['category_name']) ?></span><br>
                    <h5 class="card-title"><?= htmlspecialchars($task['name']) ?></h5>
                    <p class="card-text"><?= htmlspecialchars($task['description']) ?></p>
                    <p class="card-text"><?= htmlspecialchars($task['created_at']) ?></p>
                    <a href="task/update-task.php?id=<?= $task['id'] ?>" class="modal-link">
                        <i class='bx bxs-edit-alt'></i>
                    </a>
                    <a href="task/delete-task.php?id=<?= $task['id'] ?>" class="me-2" onclick="return confirm('Êtes-vous sûr de vouloir supprimer cette tâche ?');">
                        <i class='bx bx-trash'></i>
                    </a>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
    <?php
}