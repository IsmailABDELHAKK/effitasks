<?php

function getTaskByStatus($status) {
    $dsn = "mysql:host=localhost;dbname=effitasks";
    $pdo = new PDO($dsn, 'root', 'root');
    $sql = "SELECT tasks.*, users.first_name AS user_first_name, users.last_name AS user_last_name,
            status.name AS status_name, categories.name AS category_name, importances.name AS importance_name
            FROM tasks
            LEFT JOIN status ON tasks.status_id = status.id
            LEFT JOIN categories ON tasks.categorie_id = categories.id
            LEFT JOIN users ON tasks.user_id = users.id
            LEFT JOIN importances ON tasks.importance_id = importances.id
            WHERE status.name = :status";

    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':status', $status, PDO::PARAM_STR);
    $stmt->execute();

    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>
